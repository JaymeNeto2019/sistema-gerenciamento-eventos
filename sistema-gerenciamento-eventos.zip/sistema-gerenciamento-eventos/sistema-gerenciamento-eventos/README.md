# Sistema de Gerenciamento de Eventos

Projeto acadêmico para a disciplina de Teste de Software. O sistema possui autenticação, CRUD de eventos, API REST, banco SQLite e exemplos de testes unitários, de API e E2E.

## Tecnologias

- Frontend: HTML, CSS e JavaScript
- Backend/API: Node.js + Express
- Banco de dados: SQLite
- Testes unitários: Jest
- Testes de API: Postman
- Testes E2E: Cypress

## Como executar no Windows

1. Instale o Node.js LTS.
2. Extraia esta pasta.
3. Abra o Prompt de Comando dentro da pasta do projeto.
4. Execute:

```bash
npm install
```

5. Inicie o sistema:

```bash
npm start
```

6. Abra no navegador:

```text
http://localhost:3000
```

### Usuário de teste

- E-mail: `usuario@email.com`
- Senha: `123456`

O banco SQLite é criado automaticamente no primeiro `npm start` em `data/events.db`.

## Testes unitários

Com as dependências instaladas:

```bash
npm test
```

Os testes cobrem os casos CT-013, CT-014, CT-015 e CT-024.

## Testes E2E com Cypress

Deixe o sistema rodando em um terminal com `npm start` e abra outro terminal na pasta do projeto.

Interface do Cypress:

```bash
npm run cypress:open
```

Execução automática:

```bash
npm run cypress:run
```

## Testes de API com Postman

Importe o arquivo:

`postman/Sistema_Eventos.postman_collection.json`

A coleção executa login e guarda automaticamente o token. Depois execute os testes de eventos na ordem apresentada.

## Estrutura

```text
src/                 Backend, API e banco
public/              Frontend
 tests/unit/          Testes Jest
cypress/e2e/          Testes E2E
postman/              Coleção de testes de API
docs/                 Orientações e evidências
```

## GitHub

Depois de testar localmente, crie um repositório no GitHub e envie todos os arquivos, exceto `node_modules` e o arquivo `.db` (já incluídos no `.gitignore`).
