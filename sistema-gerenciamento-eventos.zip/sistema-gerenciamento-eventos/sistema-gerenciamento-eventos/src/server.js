const path = require('path');
const express = require('express');
const { initDatabase } = require('./db');
const authRoutes = require('./routes/auth');
const eventRoutes = require('./routes/events');
const { authRequired } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', application: 'Sistema de Gerenciamento de Eventos' });
});

app.use('/api', authRoutes);
app.use('/api/events', authRequired, eventRoutes);

app.use('/api', (req, res) => {
  res.status(404).json({ message: 'Rota não encontrada.' });
});

initDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Servidor rodando em http://localhost:${PORT}`);
      console.log('Usuário de teste: usuario@email.com | Senha: 123456');
    });
  })
  .catch((error) => {
    console.error('Erro ao iniciar banco de dados:', error);
    process.exit(1);
  });
