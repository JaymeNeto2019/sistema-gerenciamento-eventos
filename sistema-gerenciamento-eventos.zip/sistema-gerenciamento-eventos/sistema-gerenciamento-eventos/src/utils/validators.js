function isValidDateString(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return false;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
}

function validateEvent(event) {
  const errors = [];

  if (!event || typeof event !== 'object') {
    return { valid: false, errors: ['Dados do evento são obrigatórios.'] };
  }

  if (!String(event.nome || '').trim()) errors.push('O campo nome é obrigatório.');
  if (!String(event.data || '').trim()) errors.push('O campo data é obrigatório.');
  if (!String(event.horario || '').trim()) errors.push('O campo horário é obrigatório.');
  if (!String(event.local || '').trim()) errors.push('O campo local é obrigatório.');
  if (!String(event.status || '').trim()) errors.push('O campo status é obrigatório.');

  const vagas = Number(event.vagas);
  if (!Number.isInteger(vagas) || vagas <= 0) {
    errors.push('A quantidade de vagas deve ser um número inteiro maior que zero.');
  }

  if (event.data && !isValidDateString(event.data)) {
    errors.push('A data informada é inválida.');
  }

  return { valid: errors.length === 0, errors };
}

function isValidEventName(name) {
  return typeof name === 'string' && name.trim().length > 0;
}

function isValidCapacity(vagas) {
  const value = Number(vagas);
  return Number.isInteger(value) && value > 0;
}

module.exports = {
  isValidDateString,
  validateEvent,
  isValidEventName,
  isValidCapacity
};
