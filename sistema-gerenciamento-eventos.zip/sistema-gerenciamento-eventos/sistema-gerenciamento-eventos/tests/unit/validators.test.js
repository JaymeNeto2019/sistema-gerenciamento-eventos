const {
  isValidDateString,
  isValidEventName,
  isValidCapacity,
  validateEvent
} = require('../../src/utils/validators');

describe('Validações do evento', () => {
  test('CT-013: rejeita nome vazio', () => {
    expect(isValidEventName('')).toBe(false);
    expect(isValidEventName('   ')).toBe(false);
  });

  test('CT-014: rejeita quantidade de vagas negativa', () => {
    expect(isValidCapacity(-10)).toBe(false);
  });

  test('CT-015: rejeita data inválida', () => {
    expect(isValidDateString('2026-10-32')).toBe(false);
  });

  test('CT-024: aceita nome válido', () => {
    expect(isValidEventName('Feira de Tecnologia')).toBe(true);
  });

  test('aceita um evento completo e válido', () => {
    const event = {
      nome: 'Feira de Tecnologia',
      descricao: 'Evento sobre inovação e tecnologia',
      data: '2026-10-25',
      horario: '19:00',
      local: 'Brasília',
      vagas: 100,
      status: 'Ativo'
    };

    expect(validateEvent(event)).toEqual({ valid: true, errors: [] });
  });
});
