# Demonstração de um teste falhando

Esta demonstração é opcional e serve apenas para mostrar ao professor que a ferramenta detecta divergências entre o resultado esperado e o obtido.

## Opção mais simples: Jest

No arquivo `tests/unit/validators.test.js`, localize temporariamente:

```js
expect(isValidEventName('Feira de Tecnologia')).toBe(true);
```

Troque APENAS PARA A DEMONSTRAÇÃO por:

```js
expect(isValidEventName('Feira de Tecnologia')).toBe(false);
```

Execute:

```bash
npm test
```

O Jest deverá mostrar um teste em vermelho (`FAIL`), porque a função retorna `true`, mas o teste espera `false`.

Tire o print se o professor pedir.

## Muito importante

Depois da demonstração, devolva a linha para:

```js
expect(isValidEventName('Feira de Tecnologia')).toBe(true);
```

Execute `npm test` novamente e confirme que tudo aparece como `PASS` antes da entrega.
