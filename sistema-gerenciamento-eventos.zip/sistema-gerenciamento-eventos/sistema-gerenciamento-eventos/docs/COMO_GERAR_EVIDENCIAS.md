# Como gerar as evidências para o relatório

## 1. Sistema funcionando

Com `npm start` rodando, tire prints de:

1. Tela de login.
2. Tela principal com pelo menos um evento cadastrado.
3. Cadastro de evento concluído.
4. Edição de evento concluída.
5. Confirmação/exclusão de evento.

## 2. Testes unitários — Jest

Execute:

```bash
npm test
```

Tire um print do terminal mostrando os testes com `PASS`.

## 3. Testes de API — Postman

Importe `postman/Sistema_Eventos.postman_collection.json`.

Tire prints de pelo menos:

- login válido com resposta de sucesso;
- login inválido com erro controlado;
- cadastro válido de evento;
- cadastro sem nome retornando erro;
- consulta, edição e exclusão.

## 4. Testes E2E — Cypress

Com o servidor rodando, execute:

```bash
npm run cypress:run
```

Tire print do resumo dos testes passando.

## 5. Demonstração de teste que falha

O professor comentou que é interessante demonstrar um teste passando e outro falhando. Use o arquivo `docs/DEMO_TESTE_FALHANDO.md` somente para a demonstração. Depois restaure o teste correto antes da entrega final.

## 6. Organização das evidências

Crie uma pasta `evidencias/` no repositório e salve os prints com nomes como:

- `01-login.png`
- `02-jest-pass.png`
- `03-postman-login-sucesso.png`
- `04-postman-erro-campo-obrigatorio.png`
- `05-cypress-pass.png`
