# Resultados das execuções e evidências

> Preencher depois de executar os testes no computador do grupo.

## Testes unitários

- Ferramenta: Jest
- Resultado: [preencher]
- Quantidade aprovada: [preencher]
- Quantidade reprovada: [preencher]
- Evidência: [nome do print]

## Testes de API

- Ferramenta: Postman
- Resultado geral: [preencher]
- Casos executados: [preencher]
- Bugs/falhas encontrados: [preencher]
- Evidências: [nomes dos prints]

## Testes E2E

- Ferramenta: Cypress
- Resultado: [preencher]
- Quantidade aprovada: [preencher]
- Quantidade reprovada: [preencher]
- Evidência: [nome do print]

## Bugs e falhas encontradas

Caso nenhum erro real seja encontrado, registrar: "Durante as execuções planejadas não foram identificadas falhas funcionais que impedissem a conclusão dos casos de teste. Cenários inválidos foram tratados conforme os critérios de aceitação."

## Conclusão e lições aprendidas

[Preencher após a execução real dos testes.]
